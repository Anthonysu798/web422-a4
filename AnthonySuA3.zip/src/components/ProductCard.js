import Image from 'next/image';

export default function ProductCard({ product }) {
  return (
    <div className="product-card">
      <h3><strong>Rating:</strong> {product.rating.rate}</h3>
      <div className="image-container flex justify-center">
        <Image src={product.image} alt={product.title} width={250} height={200} className="object-contain" />
      </div>
      <div className="product-info">
        <p><strong>Price:</strong> ${product.price}</p>
        <p><strong>Description:</strong> {product.description}</p>
      </div>
    </div>
  );
}
