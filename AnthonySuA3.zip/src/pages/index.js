import Head from 'next/head';
import ProductCard from '../components/ProductCard';
import { useEffect, useState } from 'react';
import Image from 'next/image';

export default function Home() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch('https://fakestoreapi.com/products')
      .then((res) => res.json())
      .then((data) => setProducts(data));
  }, []);

  return (
    <div>
      <Head>
        <title>My Product App</title>
      </Head>
      <header className="header bg-purple-950">
        
        
        <div className="container mx-auto lg:px-0 md:px-0 px-4">
        <Image src="/SenecaLogo.png" alt="Organization Logo" width={200} height={200} />
        <h2 className="text-3xl font-bold text-white">We sell everything your heart desires. If you can think it, we sell it.</h2>
        <h2 className="text-3xl font-bold text-white">Our Favourites</h2>
        </div>
        
      </header>
      <main className="bg-purple-800 py-4">
        
        <div className="product-gallery container mx-auto lg:px-0 md:px-0 px-4 "> 
          <div className="grid lg:grid-cols-3 xl:grid-cols-4 md:grid-cols-2 gap-4">
          {products.map((product) => (
            <div className="bg-purple-950 my-2 rounded-lg p-3 text-white" key={product.id}> 
              <ProductCard product={product} />
            </div>
          ))}
          </div>
          
        </div>
      </main>
      
    </div>
  );
}
