module.exports = {
    images: {
      domains: ['fakestoreapi.com'],
    },
  };
  